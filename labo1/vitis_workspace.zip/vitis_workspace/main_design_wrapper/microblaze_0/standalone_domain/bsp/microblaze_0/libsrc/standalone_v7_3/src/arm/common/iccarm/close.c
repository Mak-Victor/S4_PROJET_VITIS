/******************************************************************************
* Copyright (c) 2009 - 2020 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/


#include <yfuns.h>
#include "xil_types.h"

sint32 __close(sint32 fd)
{
  (void)fd;
  return (0);

}
